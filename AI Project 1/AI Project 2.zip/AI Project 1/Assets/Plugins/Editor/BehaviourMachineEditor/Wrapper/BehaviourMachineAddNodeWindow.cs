//----------------------------------------------
//            Behaviour Machine
// Copyright © 2014 Anderson Campos Cardoso
//----------------------------------------------

using UnityEngine;
using System.Collections;

/// <summary>
/// Wrapper class for AddNodeWindow.
/// <summary>
class BehaviourMachineAddNodeWindow : BehaviourMachineEditor.AddNodeWindow {}
