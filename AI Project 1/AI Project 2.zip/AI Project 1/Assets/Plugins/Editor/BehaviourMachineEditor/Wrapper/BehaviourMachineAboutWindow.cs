using UnityEngine;
using System.Collections;

/// <summary>
/// Wrapper class for AboutWindow.
/// </summary>
class BehaviourMachineAboutWindow : BehaviourMachineEditor.AboutWindow {}
