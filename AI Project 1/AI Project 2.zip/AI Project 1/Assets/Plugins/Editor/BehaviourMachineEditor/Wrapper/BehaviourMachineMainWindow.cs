//----------------------------------------------
//            Behaviour Machine
// Copyright © 2014 Anderson Campos Cardoso
//----------------------------------------------

using UnityEngine;
using UnityEditor;
using System.Collections;

/// <summary>
/// Wrapper class for Behaviour window.
/// <summary>
class BehaviourMachineMainWindow : BehaviourMachineEditor.BehaviourWindow {}
