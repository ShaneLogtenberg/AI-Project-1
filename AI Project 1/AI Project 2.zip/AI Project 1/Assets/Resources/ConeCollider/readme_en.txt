<<Version>>
1.0

<<Version changes>>
1.0
・First release

<<How to use>>
Add component to object.

<<Parameters>>
・Angle
Angle range of collider.

・Distance
Distance from this game object.

・isTrigger
Enable "isTrigger" of collider.

・isFixScale
Whether to fixed the scale regardless of parent-child relationship.

<<Contact>>
Twitter:@isemito_niko